import { IRepository } from "../interface";

export default interface ICategoryRepository<T> extends IRepository<T> {} 