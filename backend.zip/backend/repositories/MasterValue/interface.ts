import { IRepository } from "../interface";

export default interface IMasterValueRepository<T> extends IRepository<T> {} 