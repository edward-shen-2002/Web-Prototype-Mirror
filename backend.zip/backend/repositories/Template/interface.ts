import { IRepository } from "../interface";

export default interface ITemplateRepository<T> extends IRepository<T> {} 