import { IRepository } from "../interface";

export default interface IProgramRepository<T> extends IRepository<T> {} 