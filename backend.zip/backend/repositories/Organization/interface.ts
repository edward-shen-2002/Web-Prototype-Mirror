import { IRepository } from "../interface";

export default interface IOrganizationRepository<T> extends IRepository<T> {} 