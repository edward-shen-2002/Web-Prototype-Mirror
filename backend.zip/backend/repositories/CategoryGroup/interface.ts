import { IRepository } from "../interface";

export default interface ICategoryGroupRepository<T> extends IRepository<T> {} 