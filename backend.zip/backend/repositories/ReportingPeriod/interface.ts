import { IRepository } from "../interface";

export default interface IReportingPeriodRepository<T> extends IRepository<T> {} 