import User from "../../entities/User"

type ISignUp = (user: object) => void 

export default interface IUserService {
  signUp: ISignUp
}
