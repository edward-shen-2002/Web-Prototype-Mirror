export default class CategoryGroup {
  
}