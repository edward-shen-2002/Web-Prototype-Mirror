export default class OrganizationGroup {
  
}