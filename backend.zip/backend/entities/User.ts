export default class User {
  
}