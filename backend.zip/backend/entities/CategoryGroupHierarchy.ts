export default class CategoryGroupHierarchy {
  
}