export default class MasterValue {
  
}