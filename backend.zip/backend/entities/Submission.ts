export default class Submission {
  
}