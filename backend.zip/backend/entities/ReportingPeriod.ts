export default class ReportingPeriod {
  
}