import { IRepository } from "../interface";


export default interface IYearRepository<T> extends IRepository<T> {} 