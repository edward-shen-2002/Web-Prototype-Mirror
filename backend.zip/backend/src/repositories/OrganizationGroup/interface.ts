import { IRepository } from "../interface";

export default interface IOrganizationGroupRepository<T> extends IRepository<T> {} 