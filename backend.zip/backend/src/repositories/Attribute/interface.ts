import { IRepository } from "../interface";

export default interface IAttributeRepository<T> extends IRepository<T> {} 