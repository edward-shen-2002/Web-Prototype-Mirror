import { IRepository } from "../interface";

export default interface ISubmissionRepository<T> extends IRepository<T> {} 