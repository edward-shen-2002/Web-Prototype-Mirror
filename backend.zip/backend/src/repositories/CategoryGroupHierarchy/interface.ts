import { IRepository } from "../interface";

export default interface ICategoryGroupHierarchyRepository<T> extends IRepository<T> {} 