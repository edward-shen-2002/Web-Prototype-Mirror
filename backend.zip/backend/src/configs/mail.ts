// https://nodemailer.com/smtp/testing/

export const mailConfig: object = {
  host: 'smtp.ethereal.email',
  port: 587,
  auth: {
    user: 'julio32@ethereal.email',
    pass: 'qdjK2XgTyyHtR9zScz'
  }
}
