import { IUserManagement } from "../interface";

export default interface IAdminService extends IUserManagement {
  
}