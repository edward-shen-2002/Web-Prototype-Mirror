import IAdminservice from './interface'

export default class AdminService implements IAdminservice {
  public approveUser() {

  } 
  
  public activateUser() {

  } 

  public deActivateUser() {

  } 
}