

export interface IUserManagement {
  approveUser         : () => void
  
  activateUser        : () => void
  deActivateUser      : () => void
}