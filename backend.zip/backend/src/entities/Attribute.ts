

export default class Attribute {
  
}