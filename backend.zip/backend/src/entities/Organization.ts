export default class Organization {
  
}