export default class Year {
  
}