export default class Template {
  
}