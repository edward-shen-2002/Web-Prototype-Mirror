export default class Category {

}